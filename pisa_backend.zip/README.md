
# Pisa Backend

This is the FastAPI backend for the Pisa AI Shopping Agent.

## Deploy on Railway

1. Create a new project on Railway.
2. Connect your GitHub repo.
3. Set your environment variables from `.env.template`.
4. Done!
